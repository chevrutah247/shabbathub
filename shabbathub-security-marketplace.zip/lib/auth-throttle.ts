import { Redis } from '@upstash/redis';
import crypto from 'crypto';

const LOGIN_MAX_FAILS = 3;
const LOGIN_BLOCK_SECONDS = 60 * 60;
const LOGIN_WINDOW_SECONDS = 60 * 60;
const LOGIN_IP_MAX_PER_HOUR = 20;

const SIGNUP_EMAIL_MAX_PER_HOUR = 3;
const SIGNUP_IP_MAX_PER_HOUR = 10;

const memoryStore = new Map<string, { value: number; expiresAt: number }>();

let redis: Redis | null = null;

function getRedis(): Redis | null {
  if (redis) return redis;
  const url = process.env.KV_REST_API_URL;
  const token = process.env.KV_REST_API_TOKEN;
  if (!url || !token) return null;
  redis = new Redis({ url, token });
  return redis;
}

function nowSec() {
  return Math.floor(Date.now() / 1000);
}

function hash(value: string): string {
  return crypto.createHash('sha256').update(value).digest('hex').slice(0, 24);
}

function parseIp(request: Request): string {
  const xff = request.headers.get('x-forwarded-for') || '';
  const realIp = request.headers.get('x-real-ip') || '';
  const first = xff.split(',').map((x) => x.trim()).find(Boolean);
  return first || realIp || 'unknown';
}

function safeEmail(email: string): string {
  return (email || '').trim().toLowerCase();
}

async function incrementWithTtl(key: string, ttlSeconds: number): Promise<number> {
  const r = getRedis();
  if (r) {
    const current = await r.incr(key);
    if (current === 1) await r.expire(key, ttlSeconds);
    return current;
  }

  const n = nowSec();
  const prev = memoryStore.get(key);
  if (!prev || prev.expiresAt <= n) {
    memoryStore.set(key, { value: 1, expiresAt: n + ttlSeconds });
    return 1;
  }
  const next = prev.value + 1;
  memoryStore.set(key, { value: next, expiresAt: prev.expiresAt });
  return next;
}

async function setWithTtl(key: string, value: number, ttlSeconds: number): Promise<void> {
  const r = getRedis();
  if (r) {
    await r.set(key, value, { ex: ttlSeconds });
    return;
  }
  const n = nowSec();
  memoryStore.set(key, { value, expiresAt: n + ttlSeconds });
}

async function getNumber(key: string): Promise<number | null> {
  const r = getRedis();
  if (r) {
    const v = await r.get<number>(key);
    return typeof v === 'number' ? v : null;
  }
  const n = nowSec();
  const item = memoryStore.get(key);
  if (!item || item.expiresAt <= n) {
    memoryStore.delete(key);
    return null;
  }
  return item.value;
}

async function delKey(key: string): Promise<void> {
  const r = getRedis();
  if (r) {
    await r.del(key);
    return;
  }
  memoryStore.delete(key);
}

function keysForLogin(email: string, ip: string) {
  const emailHash = hash(safeEmail(email));
  const ipHash = hash(ip);
  return {
    failKey: `auth:login:fail:${emailHash}:${ipHash}`,
    blockKey: `auth:login:block:${emailHash}:${ipHash}`,
    ipWindowKey: `auth:login:ip:${ipHash}`,
  };
}

function keysForSignup(email: string, ip: string) {
  const emailHash = hash(safeEmail(email));
  const ipHash = hash(ip);
  return {
    emailWindowKey: `auth:signup:email:${emailHash}`,
    ipWindowKey: `auth:signup:ip:${ipHash}`,
  };
}

export async function ensureLoginAllowed(email: string, request: Request): Promise<{ allowed: boolean; retryAfterSec?: number }> {
  const ip = parseIp(request);
  const { blockKey } = keysForLogin(email, ip);

  const blockedUntil = await getNumber(blockKey);
  const n = nowSec();
  if (blockedUntil && blockedUntil > n) {
    return { allowed: false, retryAfterSec: blockedUntil - n };
  }

  return { allowed: true };
}

export async function recordLoginFailure(email: string, request: Request): Promise<{ blocked: boolean; retryAfterSec?: number }> {
  const ip = parseIp(request);
  const n = nowSec();
  const { failKey, blockKey, ipWindowKey } = keysForLogin(email, ip);

  const attempts = await incrementWithTtl(failKey, LOGIN_WINDOW_SECONDS);
  const ipAttempts = await incrementWithTtl(ipWindowKey, LOGIN_WINDOW_SECONDS);
  if (ipAttempts > LOGIN_IP_MAX_PER_HOUR) {
    const blockUntil = n + LOGIN_BLOCK_SECONDS;
    await setWithTtl(blockKey, blockUntil, LOGIN_BLOCK_SECONDS);
    await delKey(failKey);
    return { blocked: true, retryAfterSec: LOGIN_BLOCK_SECONDS };
  }

  if (attempts >= LOGIN_MAX_FAILS) {
    const blockUntil = n + LOGIN_BLOCK_SECONDS;
    await setWithTtl(blockKey, blockUntil, LOGIN_BLOCK_SECONDS);
    await delKey(failKey);
    return { blocked: true, retryAfterSec: LOGIN_BLOCK_SECONDS };
  }

  return { blocked: false };
}

export async function clearLoginFailures(email: string, request: Request): Promise<void> {
  const ip = parseIp(request);
  const { failKey, blockKey } = keysForLogin(email, ip);
  await delKey(failKey);
  await delKey(blockKey);
}

export async function ensureSignupAllowed(email: string, request: Request): Promise<{ allowed: boolean; retryAfterSec?: number }> {
  const ip = parseIp(request);
  const { emailWindowKey, ipWindowKey } = keysForSignup(email, ip);

  const emailCount = await incrementWithTtl(emailWindowKey, LOGIN_WINDOW_SECONDS);
  const ipCount = await incrementWithTtl(ipWindowKey, LOGIN_WINDOW_SECONDS);

  if (emailCount > SIGNUP_EMAIL_MAX_PER_HOUR || ipCount > SIGNUP_IP_MAX_PER_HOUR) {
    return { allowed: false, retryAfterSec: LOGIN_BLOCK_SECONDS };
  }

  return { allowed: true };
}

export function loginPolicy() {
  return {
    maxFails: LOGIN_MAX_FAILS,
    blockSeconds: LOGIN_BLOCK_SECONDS,
  };
}
