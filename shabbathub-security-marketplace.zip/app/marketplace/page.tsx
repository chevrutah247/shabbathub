'use client';

import { useMemo, useState } from 'react';
import { Search, MapPin, UtensilsCrossed, Package, Loader2 } from 'lucide-react';

type Item = {
  id: string;
  title: string;
  description: string | null;
  price: number | null;
  currency: string | null;
  country: string | null;
  city: string | null;
  district: string | null;
  dishes: string[] | null;
  products: string[] | null;
  photos: string[] | null;
  seller_name: string | null;
  seller_contact: string | null;
};

export default function MarketplacePage() {
  const [q, setQ] = useState('');
  const [country, setCountry] = useState('');
  const [city, setCity] = useState('');
  const [district, setDistrict] = useState('');
  const [dishes, setDishes] = useState('');
  const [products, setProducts] = useState('');
  const [loading, setLoading] = useState(false);
  const [items, setItems] = useState<Item[]>([]);
  const [error, setError] = useState<string | null>(null);

  const queryString = useMemo(() => {
    const p = new URLSearchParams();
    if (q.trim()) p.set('q', q.trim());
    if (country.trim()) p.set('country', country.trim());
    if (city.trim()) p.set('city', city.trim());
    if (district.trim()) p.set('district', district.trim());
    if (dishes.trim()) p.set('dishes', dishes.trim());
    if (products.trim()) p.set('products', products.trim());
    p.set('limit', '30');
    return p.toString();
  }, [q, country, city, district, dishes, products]);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/marketplace/search?' + queryString);
      const payload = await res.json();
      if (!res.ok) throw new Error(payload?.error || 'Ошибка поиска');
      setItems(Array.isArray(payload?.items) ? payload.items : []);
    } catch (err: any) {
      setError(err?.message || 'Ошибка поиска');
      setItems([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-white px-4 py-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl md:text-4xl font-bold text-stone-900 mb-2">Кошерный маркетплейс</h1>
        <p className="text-stone-600 mb-8">Поиск по странам, городам, районам, блюдам и продуктам</p>

        <form onSubmit={handleSearch} className="bg-white border border-stone-200 rounded-2xl p-4 md:p-5 mb-8 shadow-sm">
          <div className="grid grid-cols-1 md:grid-cols-6 gap-3">
            <div className="md:col-span-2 relative">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Общий поиск" className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-stone-300 outline-none focus:border-amber-500" />
            </div>
            <input value={country} onChange={(e) => setCountry(e.target.value)} placeholder="Страна" className="px-3 py-2.5 rounded-lg border border-stone-300 outline-none focus:border-amber-500" />
            <input value={city} onChange={(e) => setCity(e.target.value)} placeholder="Город" className="px-3 py-2.5 rounded-lg border border-stone-300 outline-none focus:border-amber-500" />
            <input value={district} onChange={(e) => setDistrict(e.target.value)} placeholder="Район" className="px-3 py-2.5 rounded-lg border border-stone-300 outline-none focus:border-amber-500" />
            <button type="submit" disabled={loading} className="bg-stone-900 text-white rounded-lg px-4 py-2.5 hover:bg-stone-800 disabled:opacity-60 inline-flex items-center justify-center gap-2">
              {loading ? <Loader2 size={16} className="animate-spin" /> : <Search size={16} />} Найти
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
            <div className="relative">
              <UtensilsCrossed size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input value={dishes} onChange={(e) => setDishes(e.target.value)} placeholder="Блюда (через запятую)" className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-stone-300 outline-none focus:border-amber-500" />
            </div>
            <div className="relative">
              <Package size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input value={products} onChange={(e) => setProducts(e.target.value)} placeholder="Продукты (через запятую)" className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-stone-300 outline-none focus:border-amber-500" />
            </div>
          </div>
        </form>

        {error && <div className="mb-6 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700">{error}</div>}

        {loading ? (
          <div className="py-24 flex items-center justify-center"><Loader2 className="animate-spin text-stone-500" /></div>
        ) : items.length === 0 ? (
          <div className="py-16 text-center text-stone-500">Нет объявлений по вашему запросу</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {items.map((item) => {
              const photo = Array.isArray(item.photos) && item.photos.length > 0 ? item.photos[0] : null;
              return (
                <article key={item.id} className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-sm">
                  <div className="aspect-[4/3] bg-stone-100">
                    {photo ? <img src={photo} alt={item.title} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-stone-400">Без фото</div>}
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-stone-900 mb-1 line-clamp-1">{item.title}</h3>
                    <div className="text-sm text-stone-600 flex items-center gap-1 mb-2"><MapPin size={14} />{[item.country, item.city, item.district].filter(Boolean).join(', ') || 'Локация не указана'}</div>
                    {item.description && <p className="text-sm text-stone-600 line-clamp-2 mb-2">{item.description}</p>}
                    <div className="text-sm text-stone-700 mb-1">{item.price != null ? `${item.price} ${item.currency || ''}` : 'Цена по договоренности'}</div>
                    <div className="text-xs text-stone-500">Продавец: {item.seller_name || 'Не указан'} {item.seller_contact ? `• ${item.seller_contact}` : ''}</div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
